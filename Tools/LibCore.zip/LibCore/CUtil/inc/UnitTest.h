#ifndef __cutil_unit_test_h__
#define __cutil_unit_test_h__ 
#include "CUtil/inc/Common.h" 

namespace CUtil
{ 
	extern void DLL_EXPORT UnitTestStart(void); 
}

#endif