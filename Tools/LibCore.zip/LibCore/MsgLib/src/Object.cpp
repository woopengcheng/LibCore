#include "MsgLib/inc/Object.h"
#include "Marshal/inc/CStream.h"


namespace Msg
{

// 
// 	CUtil::CStream & Object::marshal( CUtil::CStream & cs )
// 	{
// 		cs << m_llObjID;
// 
// 		return cs;
// 	}
// 
// 	CUtil::CStream & Object::unMarshal( CUtil::CStream & cs )
// 	{
// 		cs >> m_llObjID;
// 
// 		return cs;
// 	}

}