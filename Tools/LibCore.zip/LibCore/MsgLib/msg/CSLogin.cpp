#include "GameMsgProcess.h"


namespace Game
{
	// msgid:1 name:CSLogin
	INT32 GameMsgProcess::Process(Net::ISession * pSession , ::Net::accsrv::CSLogin& msg)
	{
		return -1;
	}
} //end namespace Game

