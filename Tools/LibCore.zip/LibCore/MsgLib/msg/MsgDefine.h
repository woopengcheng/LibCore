#ifndef __msg_define_38801B0E_87A8_4E87_85DF_F6E194F26EE6_h__
#define __msg_define_38801B0E_87A8_4E87_85DF_F6E194F26EE6_h__


namespace Net
{
	namespace accsrv
	{
		const int msgid_CSLogin = 1;
		const int msgid_SCLoginResult = 2;
	} //end namespace accsrv

} //end namespace Net

#endif //__msg_define_38801B0E_87A8_4E87_85DF_F6E194F26EE6_h__


