#ifndef __timer_timer_class_type_id_h__
#define __timer_timer_class_type_id_h__
#include "Timer/inc/TimerCommon.h"

namespace Timer
{
}
#endif