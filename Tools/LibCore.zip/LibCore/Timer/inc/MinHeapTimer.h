#ifndef __timer_min_heap_timer_h
#define __timer_min_heap_timer_h
#include "CUtil/inc/MinHeap.h"
#include "Timer/inc/TimerNode.h"
#include "Timer/inc/IStrategy.h"

namespace Timer
{ 
	class DLL_EXPORT MinHeapTimer : public CUtil::MinHeap<TimerNode> , public IStrategy
	{
	public:
		MinHeapTimer( void ){}
		virtual ~MinHeapTimer( void ){} 

	public:
		virtual CErrno		Init( void )override { return CErrno::Success(); }
		virtual CErrno		Cleanup( void ) override { return CErrno::Success(); }
		virtual TimerNode *	Update(void) override
		{ 
			TimerNode * pTimerNode = NULL;
			TimerNode * pNode = CUtil::MinHeap<TimerNode>::Update();
			if (pNode)
			{
				pTimerNode = dynamic_cast<TimerNode *>(pNode);
// 				if (NULL != pTimerNode)
// 				{
// 					CUtil::MinHeap<TimerNode>::RemoveNode(pTimerNode->GetTimerID());
// 				}
			} 

			return pTimerNode;
		}
 		virtual CErrno		SetTimer(UINT32 unTimeInterval , UINT32 unTimes, UINT32 unStartTime , void * pObj = NULL , TimerCallBackFunc pFunc = NULL){ return CErrno::Success(); }

	public:
		virtual CErrno		InsertNode(UINT32 unNodeID ,TimerNode * pNode, bool bRemoveSame = true) override
		{
			return CUtil::MinHeap<TimerNode>::InsertNode(unNodeID , pNode);
		}
		virtual CErrno		RemoveNode(UINT32 unNodeID) override
		{
			return CUtil::MinHeap<TimerNode>::RemoveNode(unNodeID);
		}

		virtual TimerNode * GetNode(UINT32 unNodeID) override
		{ 
			TimerNode* pNode = CUtil::MinHeap<TimerNode>::GetNode(unNodeID);
			if (pNode)
			{
				TimerNode * pTimerNode = dynamic_cast<TimerNode*>(pNode);
				return pTimerNode;
			}
			return NULL;
		}

	};
 } 
#endif