﻿#include "Timer/inc/TimerTask.h" 

namespace Timer
{
	void TimerTask::OnTimer( UINT32 unTimerID , UINT32 unTimers )
	{

	} 

	INT32 TimerTask::SetTimer( UINT32 unInterval , UINT32 unTimes , UINT32 unStartTimer /*= 0*/  , UINT32 unTimerID /*= 0*/)
	{   
		return -1;
	} 
}