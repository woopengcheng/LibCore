/************************************
FileName	:	RpcCallFuncs.h
Author		:	generate by tools
HostName	:	DESKTOP-5AT4DK2
IP			:	192.168.31.196
Version		:	0.0.1
Description	:	�ͻ��˵��õ�rpc.
************************************/
#ifndef __msg_rpc_call_funcs_h__
#define __msg_rpc_call_funcs_h__

#include "MsgLib/inc/MsgHelper.h"
#include "MsgLib/inc/RPCMsgCall.h"
#include "Test/MsgNameDefine.h"
#include "Test/RpcDatas.h"



#endif
