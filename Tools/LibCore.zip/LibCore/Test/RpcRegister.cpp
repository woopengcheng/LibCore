/************************************
FileName	:	RpcRegister.cpp
Author		:	generate by tools
HostName	:	DESKTOP-5AT4DK2
IP			:	192.168.31.196
Version		:	0.0.1
Description	:	ע��ÿ������.�Լ�������紫�ݵ���Ϣ�Ƿ�����ȷ�Ĳ���.
************************************/
#include "MsgLib/inc/RpcManager.h"
#include "MsgLib/inc/RpcCheckParams.h"
#include "CUtil/inc/Chunk.h"
#include "MsgNameDefine.h"
#include "GRpc.h"
#include "DBServer.h"
#include "DBMaster.h"
#include "DBSlave.h"
#include "ServerHandler.h"
#include "MasterHandler.h"
#include "GRpc.h"
#include "SlaveHandler.h"

namespace Server
{
}//Server

