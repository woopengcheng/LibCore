/************************************
FileName	:	GlableRpc.h
Author		:	generate by tools
HostName	:	DESKTOP-5AT4DK2
IP			:	192.168.31.196
Version		:	0.0.1
Description	:	��̬����,�޶���ʱͨ������ദ��.
************************************/
#ifndef __Server_global_rpc_h__
#define __Server_global_rpc_h__
#include "MsgLib/inc/IRpcMsgCallableObject.h" 
#include "Test/RpcDefines.h" 

	class GRpc : public Msg::IRpcMsgCallableObject
	{
		RPC_DEFINE_GRpc;
	public:
		GRpc(Msg::Object nID , Msg::RpcManager * pRpcManager)
			: Msg::IRpcMsgCallableObject(nID , pRpcManager)
		{
			GRpc::InitObjectFuncs();
		}
	public:
	};

#endif

