#include "GameDB/inc/CustomDefinedCacheHandler.h"

namespace GameDB
{
	 
	void CustomDefinedCacheHandler::Put(const Slice& objKey, const Slice& objValue)
	{

	}

	void CustomDefinedCacheHandler::Delete(const Slice& objKey)
	{

	}

}