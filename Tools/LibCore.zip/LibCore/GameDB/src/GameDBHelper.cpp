#include "GameDB/inc/GameDBHelper.h"
#include "GameDB/inc/DBCommon.h"

namespace GameDB
{
// 	const char * g_szSystemDatabase = ".sys";
// 	const char * g_szSystemUserTable = "user";


// 	LibCore::CStream & operator << (LibCore::CStream& cs,const leveldb::Slice& c)
// 	{
// 		cs << c.size();
// 		cs.Pushback((void*)c.data() , c.size());
// 		return cs;
// 	}

}